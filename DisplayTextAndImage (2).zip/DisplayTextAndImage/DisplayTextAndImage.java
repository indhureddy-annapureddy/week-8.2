import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.stage.Stage;

import java.io.File;

public class DisplayTextAndImage extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Text and Image Display");

        Label label = new Label("Hello, JavaFX!");
        label.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        // Keep imagePath.jpg in the project folder, or change this path.
        File imageFile = new File("imagePath.jpg");
        ImageView imageView;

        if (imageFile.exists()) {
            Image image = new Image(imageFile.toURI().toString());
            imageView = new ImageView(image);
            imageView.setFitWidth(400);
            imageView.setFitHeight(280);
            imageView.setPreserveRatio(true);
        } else {
            // Display a helpful placeholder if the image file is missing.
            Label imageNotice = new Label(
                "Image not found: imagePath.jpg\\nPlace an image with this name beside the program."
            );
            VBox root = new VBox(15, label, imageNotice);
            root.setAlignment(Pos.CENTER);
            Scene scene = new Scene(root, 600, 400);
            primaryStage.setScene(scene);
            primaryStage.show();
            return;
        }

        VBox root = new VBox(15, label, imageView);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 600, 400);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
