# Text and Image Display (JavaFX)

## Files
- `DisplayTextAndImage.java` — JavaFX source code.
- `imagePath.jpg` — add your own image file with this exact name.
- `output/` — save a screenshot of the running app here for your lab submission.

## Run
1. Ensure Java and JavaFX are installed and configured.
2. Put an image named `imagePath.jpg` in the same working directory as the program.
3. Compile and run with JavaFX configured. Example (adjust the JavaFX SDK path):

```bash
javac --module-path "PATH_TO_FX/lib" --add-modules javafx.controls DisplayTextAndImage.java
java --module-path "PATH_TO_FX/lib" --add-modules javafx.controls DisplayTextAndImage
```

The window is titled **Text and Image Display**, and the scene is 600 × 400 pixels.
If the image is missing, the app displays a helpful notice instead of crashing.
