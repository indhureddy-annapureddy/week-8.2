Save a screenshot of the running JavaFX application in this folder for submission.
